import React, { useState } from 'react';
import { 
  ShieldCheck, ArrowLeftRight, Clock, User, Bell, ChevronDown, 
  Search, Filter, HelpCircle, Globe, Wallet, CheckCircle2, AlertCircle, 
  X, MessageSquare, ExternalLink, RefreshCw
} from 'lucide-react';

export default function App() {
  const [activeTab, setActiveTab] = useState('p2p');
  const [tradeType, setTradeType] = useState('BUY');
  const [cryptoAsset, setCryptoAsset] = useState('USDT');
  const [fiatCurrency, setFiatCurrency] = useState('ETB');
  const [selectedPayment, setSelectedPayment] = useState('ALL');
  const [searchAmount, setSearchAmount] = useState('');
  
  // Modal states
  const [selectedAd, setSelectedAd] = useState(null);
  const [modalStep, setModalStep] = useState(1); // 1: Order details, 2: Payment info, 3: Completed/Dispute
  const [orderAmount, setOrderAmount] = useState('');
  const [orderQuantity, setOrderQuantity] = useState('');
  const [chatMessages, setChatMessages] = useState([
    { sender: 'seller', text: 'Hello! I am online. Please release payment only through Telebirr or CBE to the account details provided below.', time: '10:42 AM' }
  ]);
  const [newMessage, setNewMessage] = useState('');
  const [toast, setToast] = useState(null);

  const showToast = (msg) => {
    setToast(msg);
    setTimeout(() => setToast(null), 3000);
  };

  const adsData = [
    {
      id: 1,
      type: 'SELL', // User wants to buy from this merchant
      merchant: 'AbebeCrypto_Express',
      orders: 1420,
      completionRate: '99.4%',
      verified: true,
      price: 138.50,
      cryptoAvailable: 4500.00,
      minLimit: 5000,
      maxLimit: 150000,
      fiatSymbol: 'ETB',
      payments: ['Telebirr', 'CBE Birr', 'Commercial Bank of Ethiopia'],
      crypto: 'USDT'
    },
    {
      id: 2,
      type: 'SELL',
      merchant: 'Habesha_P2P_Hub',
      orders: 890,
      completionRate: '98.8%',
      verified: true,
      price: 138.75,
      cryptoAvailable: 2300.50,
      minLimit: 2000,
      maxLimit: 80000,
      fiatSymbol: 'ETB',
      payments: ['Telebirr', 'Awash Bank'],
      crypto: 'USDT'
    },
    {
      id: 3,
      type: 'SELL',
      merchant: 'AddisTradeFast',
      orders: 3100,
      completionRate: '100%',
      verified: true,
      price: 139.00,
      cryptoAvailable: 10000.00,
      minLimit: 10000,
      maxLimit: 500000,
      fiatSymbol: 'ETB',
      payments: ['CBE Birr', 'Dashen Bank', 'Telebirr'],
      crypto: 'USDT'
    },
    {
      id: 4,
      type: 'BUY', // User wants to sell to this merchant
      merchant: 'EthioLiquid_Pro',
      orders: 654,
      completionRate: '97.9%',
      verified: true,
      price: 137.20,
      cryptoLimit: 5000.00,
      minLimit: 1000,
      maxLimit: 50000,
      fiatSymbol: 'ETB',
      payments: ['Telebirr', 'CBE Birr'],
      crypto: 'USDT'
    },
    {
      id: 5,
      type: 'BUY',
      merchant: 'AbayExchanges',
      orders: 1250,
      completionRate: '99.1%',
      verified: true,
      price: 136.90,
      cryptoLimit: 3200.00,
      minLimit: 5000,
      maxLimit: 100000,
      fiatSymbol: 'ETB',
      payments: ['Commercial Bank of Ethiopia', 'Telebirr'],
      crypto: 'USDT'
    }
  ];

  const filteredAds = adsData.filter(ad => {
    if (tradeType === 'BUY') {
      // User wants to buy crypto -> filter ads where type === 'SELL' (merchant selling)
      return ad.type === 'SELL';
    } else {
      // User wants to sell crypto -> filter ads where type === 'BUY' (merchant buying)
      return ad.type === 'BUY';
    }
  }).filter(ad => {
    if (selectedPayment !== 'ALL') {
      return ad.payments.includes(selectedPayment);
    }
    return true;
  });

  const handleOpenTrade = (ad) => {
    setSelectedAd(ad);
    setModalStep(1);
    setOrderAmount('');
    setOrderQuantity('');
  };

  const handleSendMessage = (e) => {
    e.preventDefault();
    if (!newMessage.trim()) return;
    setChatMessages([...chatMessages, { sender: 'user', text: newMessage, time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) }]);
    setNewMessage('');
    setTimeout(() => {
      setChatMessages(prev => [...prev, { sender: 'seller', text: 'Got it! Checking my account balance now...', time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) }]);
    }, 1500);
  };

  return (
    <div className="min-h-screen bg-binance-dark text-binance-text flex flex-col font-sans">
      
      {/* TOAST NOTIFICATION */}
      {toast && (
        <div className="fixed top-20 right-5 z-50 bg-[#2B313A] border border-binance-yellow text-white px-4 py-3 rounded-lg shadow-2xl flex items-center space-x-2 animate-bounce">
          <CheckCircle2 className="text-binance-yellow w-5 h-5" />
          <span>{toast}</span>
        </div>
      )}

      {/* TOP HEADER */}
      <header className="bg-binance-card border-b border-binance-border sticky top-0 z-40">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
          <div className="flex items-center space-x-8">
            <div className="flex items-center space-x-2 cursor-pointer" onClick={() => setActiveTab('p2p')}>
              <div className="w-9 h-9 bg-binance-yellow rounded-md flex items-center justify-center font-bold text-black text-xl shadow">
                Et
              </div>
              <span className="text-xl font-bold tracking-tight text-white">Ethio<span className="text-binance-yellow">P2P</span></span>
            </div>
            
            <nav className="hidden md:flex space-x-6 text-sm font-medium">
              <button 
                onClick={() => setActiveTab('p2p')}
                className={`transition-colors py-5 border-b-2 ${activeTab === 'p2p' ? 'border-binance-yellow text-binance-yellow font-semibold' : 'border-transparent text-binance-muted hover:text-white'}`}
              >
                P2P Trading
              </button>
              <button 
                onClick={() => setActiveTab('orders')}
                className={`transition-colors py-5 border-b-2 ${activeTab === 'orders' ? 'border-binance-yellow text-binance-yellow font-semibold' : 'border-transparent text-binance-muted hover:text-white'}`}
              >
                Orders
              </button>
              <button 
                onClick={() => setActiveTab('merchant')}
                className={`transition-colors py-5 border-b-2 ${activeTab === 'merchant' ? 'border-binance-yellow text-binance-yellow font-semibold' : 'border-transparent text-binance-muted hover:text-white'}`}
              >
                Merchant Zone
              </button>
            </nav>
          </div>

          <div className="flex items-center space-x-4">
            <div className="flex items-center space-x-1 text-xs bg-[#2B313A] text-binance-yellow px-2.5 py-1 rounded-full font-semibold border border-binance-yellow/30">
              <ShieldCheck className="w-3.5 h-3.5" />
              <span>Escrow Protected</span>
            </div>
            <button className="text-binance-muted hover:text-white p-2">
              <Bell className="w-5 h-5" />
            </button>
            <div className="flex items-center space-x-2 bg-[#2B313A] px-3 py-1.5 rounded-lg border border-binance-border cursor-pointer hover:border-binance-yellow/50">
              <div className="w-7 h-7 bg-binance-yellow/20 text-binance-yellow rounded-full flex items-center justify-center font-bold text-xs">
                A
              </div>
              <span className="text-xs font-medium text-white hidden sm:inline">Abebe.ET</span>
              <ChevronDown className="w-3.5 h-3.5 text-binance-muted" />
            </div>
          </div>
        </div>
      </header>

      {/* MAIN CONTENT AREA */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-6">
        
        {activeTab === 'p2p' && (
          <div className="space-y-6">
            
            {/* HERO BANNER */}
            <div className="bg-gradient-to-r from-[#1E2329] to-[#181A20] border border-binance-border rounded-xl p-6 shadow-xl flex flex-col md:flex-row justify-between items-center">
              <div className="space-y-2 mb-4 md:mb-0">
                <div className="inline-block bg-binance-yellow/10 text-binance-yellow text-xs font-semibold px-2.5 py-1 rounded">
                  Zero Fee P2P Exchange in Ethiopia
                </div>
                <h1 className="text-2xl sm:text-3xl font-bold text-white">Buy & Sell Crypto with Ethiopian Birr (ETB)</h1>
                <p className="text-binance-muted text-sm max-w-xl">
                  Fast, secure peer-to-peer cryptocurrency trading backed by escrow. Trade safely using Telebirr, CBE Birr, and local commercial banks.
                </p>
              </div>
              <div className="flex space-x-3">
                <div className="bg-binance-card p-3 rounded-lg border border-binance-border text-center min-w-[110px]">
                  <div className="text-xs text-binance-muted">24h Volume</div>
                  <div className="text-lg font-bold text-white">4.8M ETB</div>
                </div>
                <div className="bg-binance-card p-3 rounded-lg border border-binance-border text-center min-w-[110px]">
                  <div className="text-xs text-binance-muted">Escrow Success</div>
                  <div className="text-lg font-bold text-binance-green">100%</div>
                </div>
              </div>
            </div>

            {/* TRADING FILTER CONTROLS */}
            <div className="bg-binance-card border border-binance-border rounded-xl p-4 sm:p-6 shadow-md space-y-4">
              
              {/* Tabs: Buy / Sell + Crypto Selector */}
              <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center border-b border-binance-border pb-4 gap-4">
                <div className="flex items-center space-x-2">
                  <button 
                    onClick={() => setTradeType('BUY')}
                    className={`px-6 py-2 rounded-lg font-bold text-sm transition-all ${tradeType === 'BUY' ? 'bg-binance-green text-black shadow-lg shadow-binance-green/20' : 'text-binance-muted hover:bg-[#2B313A]'}`}
                  >
                    Buy
                  </button>
                  <button 
                    onClick={() => setTradeType('SELL')}
                    className={`px-6 py-2 rounded-lg font-bold text-sm transition-all ${tradeType === 'SELL' ? 'bg-binance-red text-white shadow-lg shadow-binance-red/20' : 'text-binance-muted hover:bg-[#2B313A]'}`}
                  >
                    Sell
                  </button>

                  <div className="h-6 w-[1px] bg-binance-border mx-2"></div>

                  {['USDT', 'BTC', 'ETH'].map(asset => (
                    <button
                      key={asset}
                      onClick={() => setCryptoAsset(asset)}
                      className={`px-3 py-1.5 rounded-lg text-sm font-semibold transition-colors ${cryptoAsset === asset ? 'text-binance-yellow bg-binance-yellow/10' : 'text-binance-muted hover:text-white'}`}
                    >
                      {asset}
                    </button>
                  ))}
                </div>

                <div className="flex items-center space-x-2 text-sm text-binance-muted">
                  <span>Fiat:</span>
                  <select 
                    value={fiatCurrency} 
                    onChange={(e) => setFiatCurrency(e.target.value)}
                    className="bg-[#2B313A] border border-binance-border text-white rounded-lg px-3 py-1.5 focus:outline-none focus:border-binance-yellow"
                  >
                    <option value="ETB">ETB (Ethiopian Birr)</option>
                    <option value="USD">USD (Dollar)</option>
                  </select>
                </div>
              </div>

              {/* Sub-Filters: Amount, Payment Method */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 items-center">
                <div>
                  <label className="block text-xs text-binance-muted mb-1">Amount (ETB)</label>
                  <div className="relative">
                    <input 
                      type="number" 
                      placeholder="Enter amount" 
                      value={searchAmount}
                      onChange={(e) => setSearchAmount(e.target.value)}
                      className="w-full bg-[#2B313A] border border-binance-border rounded-lg pl-3 pr-10 py-2 text-sm text-white focus:outline-none focus:border-binance-yellow"
                    />
                    <div className="absolute right-3 top-2.5 text-xs text-binance-muted">ETB</div>
                  </div>
                </div>

                <div>
                  <label className="block text-xs text-binance-muted mb-1">Payment Method</label>
                  <select 
                    value={selectedPayment} 
                    onChange={(e) => setSelectedPayment(e.target.value)}
                    className="w-full bg-[#2B313A] border border-binance-border rounded-lg px-3 py-2 text-sm text-white focus:outline-none focus:border-binance-yellow"
                  >
                    <option value="ALL">All Payments</option>
                    <option value="Telebirr">Telebirr</option>
                    <option value="CBE Birr">CBE Birr</option>
                    <option value="Commercial Bank of Ethiopia">Commercial Bank of Ethiopia (CBE)</option>
                    <option value="Awash Bank">Awash Bank</option>
                    <option value="Dashen Bank">Dashen Bank</option>
                  </select>
                </div>

                <div className="flex justify-end items-end sm:pt-5">
                  <button 
                    onClick={() => { setSearchAmount(''); setSelectedPayment('ALL'); showToast('Filters reset successfully'); }}
                    className="text-xs text-binance-yellow hover:underline flex items-center space-x-1"
                  >
                    <RefreshCw className="w-3.5 h-3.5" />
                    <span>Reset Filters</span>
                  </button>
                </div>
              </div>

            </div>

            {/* P2P OFFERS TABLE / CARD LIST */}
            <div className="bg-binance-card border border-binance-border rounded-xl shadow-md overflow-hidden">
              <div className="overflow-x-auto">
                <table className="w-full text-left border-collapse">
                  <thead>
                    <tr className="border-b border-binance-border text-xs text-binance-muted bg-[#1E2329]/50">
                      <th className="py-4 px-6 font-medium">Merchant</th>
                      <th className="py-4 px-6 font-medium">Price</th>
                      <th className="py-4 px-6 font-medium">Available / Limit</th>
                      <th className="py-4 px-6 font-medium">Payment Methods</th>
                      <th className="py-4 px-6 font-medium text-right">Trade Action</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-binance-border text-sm">
                    {filteredAds.map((ad) => (
                      <tr key={ad.id} className="hover:bg-[#2B313A]/30 transition-colors">
                        <td className="py-4 px-6">
                          <div className="flex items-center space-x-3">
                            <div className="w-9 h-9 bg-binance-yellow/10 text-binance-yellow font-bold rounded-full flex items-center justify-center border border-binance-yellow/20">
                              {ad.merchant.charAt(0)}
                            </div>
                            <div>
                              <div className="flex items-center space-x-1">
                                <span className="font-semibold text-white">{ad.merchant}</span>
                                {ad.verified && <CheckCircle2 className="w-4 h-4 text-binance-yellow fill-binance-yellow/20" />}
                              </div>
                              <div className="text-xs text-binance-muted">
                                {ad.orders} orders • <span className="text-binance-green">{ad.completionRate}</span> completion
                              </div>
                            </div>
                          </div>
                        </td>

                        <td className="py-4 px-6">
                          <div className="text-lg font-bold text-white">
                            {ad.price.toFixed(2)} <span className="text-xs font-normal text-binance-muted">ETB</span>
                          </div>
                        </td>

                        <td className="py-4 px-6">
                          <div className="text-xs text-binance-muted space-y-0.5">
                            <div>Available: <span className="text-white font-medium">{ad.cryptoAvailable || ad.cryptoLimit} {cryptoAsset}</span></div>
                            <div>Limit: <span className="text-white font-medium">{ad.minLimit.toLocaleString()} - {ad.maxLimit.toLocaleString()} ETB</span></div>
                          </div>
                        </td>

                        <td className="py-4 px-6">
                          <div className="flex flex-wrap gap-1.5">
                            {ad.payments.map((pm, idx) => (
                              <span key={idx} className="bg-[#2B313A] text-xs px-2 py-0.5 rounded text-binance-yellow border border-binance-border">
                                {pm}
                              </span>
                            ))}
                          </div>
                        </td>

                        <td className="py-4 px-6 text-right">
                          <button 
                            onClick={() => handleOpenTrade(ad)}
                            className={`px-5 py-2 rounded-lg font-bold text-xs uppercase tracking-wide transition-all ${
                              tradeType === 'BUY' 
                                ? 'bg-binance-green text-black hover:bg-binance-greenHover' 
                                : 'bg-binance-red text-white hover:bg-binance-redHover'
                            }`}
                          >
                            {tradeType === 'BUY' ? `Buy ${cryptoAsset}` : `Sell ${cryptoAsset}`}
                          </button>
                        </td>
                      </tr>
                    ))}
                    {filteredAds.length === 0 && (
                      <tr>
                        <td colSpan="5" className="py-12 text-center text-binance-muted">
                          No offers match your filter criteria. Try resetting or selecting a different payment method.
                        </td>
                      </tr>
                    )}
                  </tbody>
                </table>
              </div>
            </div>

          </div>
        )}

        {activeTab === 'orders' && (
          <div className="space-y-6">
            <h1 className="text-2xl font-bold text-white">My P2P Orders</h1>
            <div className="bg-binance-card border border-binance-border rounded-xl p-8 text-center space-y-4">
              <div className="w-16 h-16 bg-[#2B313A] rounded-full flex items-center justify-center mx-auto text-binance-muted">
                <Clock className="w-8 h-8" />
              </div>
              <h3 className="text-lg font-semibold text-white">No Active Orders</h3>
              <p className="text-sm text-binance-muted max-w-sm mx-auto">
                You currently have no pending or active P2P trade orders. Go to P2P Trading to buy or sell USDT.
              </p>
              <button 
                onClick={() => setActiveTab('p2p')}
                className="bg-binance-yellow text-black px-6 py-2 rounded-lg font-bold text-sm hover:bg-binance-yellowHover"
              >
                Start Trading Now
              </button>
            </div>
          </div>
        )}

        {activeTab === 'merchant' && (
          <div className="space-y-6">
            <div className="bg-gradient-to-r from-binance-yellow/10 to-transparent border border-binance-yellow/30 rounded-xl p-6">
              <h1 className="text-2xl font-bold text-white mb-2">Ethio P2P Merchant Program</h1>
              <p className="text-binance-muted text-sm max-w-2xl mb-4">
                Unlock higher limits, verified badge status, zero maker fees, and dedicated escrow support.
              </p>
              <button 
                onClick={() => showToast('Merchant application submitted successfully! Our verification team will contact you.')}
                className="bg-binance-yellow text-black px-6 py-2.5 rounded-lg font-bold text-sm hover:bg-binance-yellowHover shadow-md"
              >
                Apply for Verified Merchant
              </button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div className="bg-binance-card border border-binance-border rounded-xl p-6 space-y-2">
                <ShieldCheck className="w-8 h-8 text-binance-yellow" />
                <h3 className="font-bold text-white text-lg">Guaranteed Escrow</h3>
                <p className="text-xs text-binance-muted leading-relaxed">All digital assets are locked in smart escrow during fiat transfer confirmation.</p>
              </div>
              <div className="bg-binance-card border border-binance-border rounded-xl p-6 space-y-2">
                <User className="w-8 h-8 text-binance-green" />
                <h3 className="font-bold text-white text-lg">Local Fiat Gateways</h3>
                <p className="text-xs text-binance-muted leading-relaxed">Direct support for Telebirr, CBE Birr, and all major Ethiopian banks.</p>
              </div>
              <div className="bg-binance-card border border-binance-border rounded-xl p-6 space-y-2">
                <Wallet className="w-8 h-8 text-binance-yellow" />
                <h3 className="font-bold text-white text-lg">Instant Settlement</h3>
                <p className="text-xs text-binance-muted leading-relaxed">Average trade execution time under 5 minutes with active merchant liquidity.</p>
              </div>
            </div>
          </div>
        )}

      </main>

      {/* FOOTER */}
      <footer className="bg-binance-card border-t border-binance-border mt-12 py-8">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col sm:flex-row justify-between items-center text-xs text-binance-muted gap-4">
          <div>© 2026 Ethio P2P Platform. Powered by Binance Design Architecture.</div>
          <div className="flex space-x-6">
            <span className="hover:text-white cursor-pointer">Privacy Policy</span>
            <span className="hover:text-white cursor-pointer">Terms of Service</span>
            <span className="hover:text-white cursor-pointer">Escrow Rules</span>
            <span className="hover:text-white cursor-pointer">Support</span>
          </div>
        </div>
      </footer>

      {/* TRADE MODAL */}
      {selectedAd && (
        <div className="fixed inset-0 z-50 bg-black/80 flex items-center justify-center p-4 backdrop-blur-sm">
          <div className="bg-binance-card border border-binance-border rounded-2xl max-w-xl w-full p-6 space-y-6 shadow-2xl relative animate-in fade-in zoom-in duration-200">
            
            <button 
              onClick={() => setSelectedAd(null)}
              className="absolute top-4 right-4 text-binance-muted hover:text-white"
            >
              <X className="w-5 h-5" />
            </button>

            {/* Modal Step 1: Input amount */}
            {modalStep === 1 && (
              <div className="space-y-6">
                <div className="flex items-center space-x-3 border-b border-binance-border pb-4">
                  <div className="w-10 h-10 bg-binance-yellow/10 text-binance-yellow font-bold rounded-full flex items-center justify-center text-lg">
                    {selectedAd.merchant.charAt(0)}
                  </div>
                  <div>
                    <h3 className="text-lg font-bold text-white">
                      {tradeType === 'BUY' ? 'Buy' : 'Sell'} {cryptoAsset} from {selectedAd.merchant}
                    </h3>
                    <div className="text-xs text-binance-muted">Unit Price: <span className="text-binance-yellow font-bold">{selectedAd.price} ETB</span></div>
                  </div>
                </div>

                <div className="space-y-4">
                  <div className="bg-[#2B313A]/50 p-4 rounded-xl border border-binance-border space-y-3">
                    <div className="flex justify-between items-center">
                      <span className="text-xs text-binance-muted">I want to pay</span>
                      <div className="relative flex-1 max-w-[240px]">
                        <input 
                          type="number" 
                          placeholder="0.00" 
                          value={orderAmount}
                          onChange={(e) => {
                            setOrderAmount(e.target.value);
                            setOrderQuantity(e.target.value ? (parseFloat(e.target.value) / selectedAd.price).toFixed(2) : '');
                          }}
                          className="w-full bg-[#181A20] border border-binance-border rounded-lg px-3 py-2 text-right text-white font-bold focus:outline-none focus:border-binance-yellow"
                        />
                      </div>
                      <span className="ml-2 font-semibold text-white">ETB</span>
                    </div>

                    <div className="flex justify-between items-center">
                      <span className="text-xs text-binance-muted">I will receive</span>
                      <div className="relative flex-1 max-w-[240px]">
                        <input 
                          type="number" 
                          placeholder="0.00" 
                          value={orderQuantity}
                          onChange={(e) => {
                            setOrderQuantity(e.target.value);
                            setOrderAmount(e.target.value ? (parseFloat(e.target.value) * selectedAd.price).toFixed(2) : '');
                          }}
                          className="w-full bg-[#181A20] border border-binance-border rounded-lg px-3 py-2 text-right text-white font-bold focus:outline-none focus:border-binance-yellow"
                        />
                      </div>
                      <span className="ml-2 font-semibold text-white">{cryptoAsset}</span>
                    </div>
                  </div>

                  <div className="space-y-2">
                    <label className="text-xs text-binance-muted block">Select Payment Method</label>
                    <div className="grid grid-cols-2 gap-2">
                      {selectedAd.payments.map((pm, i) => (
                        <div key={i} className="bg-[#2B313A] border border-binance-yellow/50 rounded-lg p-2.5 text-xs text-white font-medium flex items-center space-x-2">
                          <div className="w-2 h-2 rounded-full bg-binance-yellow"></div>
                          <span>{pm}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>

                <div className="flex justify-end space-x-3 pt-2">
                  <button 
                    onClick={() => setSelectedAd(null)}
                    className="px-5 py-2.5 rounded-lg text-sm font-medium text-binance-muted hover:bg-[#2B313A]"
                  >
                    Cancel
                  </button>
                  <button 
                    onClick={() => {
                      if (!orderAmount || parseFloat(orderAmount) <= 0) {
                        showToast('Please enter a valid amount');
                        return;
                      }
                      setModalStep(2);
                    }}
                    className="bg-binance-yellow text-black px-6 py-2.5 rounded-lg font-bold text-sm hover:bg-binance-yellowHover shadow-lg"
                  >
                    Confirm Order & Escrow Lock
                  </button>
                </div>
              </div>
            )}

            {/* Modal Step 2: Payment & Escrow Live Screen */}
            {modalStep === 2 && (
              <div className="space-y-6">
                <div className="flex justify-between items-center border-b border-binance-border pb-3">
                  <div className="flex items-center space-x-2">
                    <span className="bg-binance-yellow/20 text-binance-yellow text-xs px-2 py-0.5 rounded font-bold">Escrow Locked</span>
                    <span className="text-sm font-bold text-white">Order #ETHIO-98241</span>
                  </div>
                  <div className="text-xs text-binance-red font-semibold flex items-center space-x-1">
                    <Clock className="w-3.5 h-3.5" />
                    <span>14:59 remaining</span>
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="bg-[#2B313A]/40 p-4 rounded-xl border border-binance-border space-y-3">
                    <h4 className="text-xs font-semibold text-binance-yellow uppercase tracking-wider">Merchant Payment Details</h4>
                    <div className="space-y-2 text-xs">
                      <div>
                        <span className="text-binance-muted block">Bank / Wallet:</span>
                        <span className="font-bold text-white text-sm">Telebirr / CBE Birr</span>
                      </div>
                      <div>
                        <span className="text-binance-muted block">Account Name:</span>
                        <span className="font-bold text-white text-sm">Abebe Kebede</span>
                      </div>
                      <div>
                        <span className="text-binance-muted block">Account Number / Phone:</span>
                        <span className="font-bold text-binance-yellow text-base select-all">+251 91 234 5678</span>
                      </div>
                      <div className="pt-2 border-t border-binance-border flex justify-between">
                        <span className="text-binance-muted">Amount to Transfer:</span>
                        <span className="font-bold text-white text-sm">{orderAmount} ETB</span>
                      </div>
                    </div>
                  </div>

                  {/* Live Chat with Seller */}
                  <div className="bg-[#181A20] rounded-xl border border-binance-border flex flex-col h-56 p-3">
                    <div className="text-xs font-semibold text-binance-muted border-b border-binance-border pb-2 mb-2 flex items-center justify-between">
                      <span>Chat with Merchant</span>
                      <span className="w-2 h-2 rounded-full bg-binance-green"></span>
                    </div>
                    <div className="flex-1 overflow-y-auto space-y-2 text-xs pr-1">
                      {chatMessages.map((msg, idx) => (
                        <div key={idx} className={`flex flex-col ${msg.sender === 'user' ? 'items-end' : 'items-start'}`}>
                          <div className={`p-2 rounded-lg max-w-[85%] ${msg.sender === 'user' ? 'bg-binance-yellow text-black font-medium' : 'bg-[#2B313A] text-white'}`}>
                            {msg.text}
                          </div>
                          <span className="text-[10px] text-binance-muted mt-0.5">{msg.time}</span>
                        </div>
                      ))}
                    </div>
                    <form onSubmit={handleSendMessage} className="mt-2 flex space-x-1">
                      <input 
                        type="text" 
                        placeholder="Type message..." 
                        value={newMessage}
                        onChange={(e) => setNewMessage(e.target.value)}
                        className="flex-1 bg-[#2B313A] border border-binance-border rounded px-2 py-1 text-xs text-white focus:outline-none focus:border-binance-yellow"
                      />
                      <button type="submit" className="bg-binance-yellow text-black px-3 py-1 rounded text-xs font-bold">Send</button>
                    </form>
                  </div>
                </div>

                <div className="bg-binance-yellow/10 border border-binance-yellow/30 p-3 rounded-lg flex items-start space-x-2 text-xs text-binance-yellow">
                  <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />
                  <span>Transfer funds from your own bank account matching your verified KYC name. Do not include crypto keywords in transfer notes.</span>
                </div>

                <div className="flex justify-end space-x-3">
                  <button 
                    onClick={() => setSelectedAd(null)}
                    className="px-4 py-2 rounded-lg text-xs font-medium text-binance-muted hover:bg-[#2B313A]"
                  >
                    Cancel Order
                  </button>
                  <button 
                    onClick={() => {
                      showToast('Payment marked as transferred! Waiting for merchant release.');
                      setModalStep(3);
                    }}
                    className="bg-binance-green text-black px-6 py-2.5 rounded-lg font-bold text-xs hover:bg-binance-greenHover shadow-lg"
                  >
                    Transferred, Notify Seller
                  </button>
                </div>
              </div>
            )}

            {/* Modal Step 3: Success Completed */}
            {modalStep === 3 && (
              <div className="text-center space-y-6 py-6">
                <div className="w-16 h-16 bg-binance-green/20 text-binance-green rounded-full flex items-center justify-center mx-auto border border-binance-green/30">
                  <CheckCircle2 className="w-10 h-10" />
                </div>
                <div className="space-y-2">
                  <h3 className="text-xl font-bold text-white">Trade Completed Successfully!</h3>
                  <p className="text-xs text-binance-muted max-w-sm mx-auto">
                    {orderQuantity} {cryptoAsset} has been released from escrow to your wallet balance.
                  </p>
                </div>
                <div className="bg-[#2B313A] p-4 rounded-xl text-xs space-y-2 max-w-sm mx-auto text-left border border-binance-border">
                  <div className="flex justify-between"><span className="text-binance-muted">Order ID:</span> <span className="text-white">ETHIO-98241</span></div>
                  <div className="flex justify-between"><span className="text-binance-muted">Total Paid:</span> <span className="text-white font-bold">{orderAmount} ETB</span></div>
                  <div className="flex justify-between"><span className="text-binance-muted">Crypto Received:</span> <span className="text-binance-green font-bold">{orderQuantity} {cryptoAsset}</span></div>
                </div>
                <button 
                  onClick={() => setSelectedAd(null)}
                  className="bg-binance-yellow text-black px-8 py-2.5 rounded-lg font-bold text-sm hover:bg-binance-yellowHover shadow-lg"
                >
                  Back to Dashboard
                </button>
              </div>
            )}

          </div>
        </div>
      )}

    </div>
  );
}
